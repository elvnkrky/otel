<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Paradise - Hotel HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="index.html" class="navbar-brand w-100 h-100 m-0 p-0 d-flex align-items-center justify-content-center">
                        <h1 class="m-0 text-primary text-uppercase">Paradise</h1>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                        <div class="col-lg-7 px-5 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0">info@paradisehotel.com</p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <p class="mb-0">+012 345 6789</p>
                            </div>
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                            <div class="d-inline-flex align-items-center py-2">
                                <a class="me-3" href=""><i class="fab fa-facebook-f"></i></a>
                                <a class="me-3" href=""><i class="fab fa-twitter"></i></a>
                                <a class="me-3" href=""><i class="fab fa-linkedin-in"></i></a>
                                <a class="me-3" href=""><i class="fab fa-instagram"></i></a>
                                <a class="" href=""><i class="fab fa-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="index.html" class="navbar-brand d-block d-lg-none">
                            <h1 class="m-0 text-primary text-uppercase">Paradise</h1>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="index.html" class="nav-item nav-link">Anasayfa</a>
                                <a href="about.html" class="nav-item nav-link">Hakkında</a>
                                <a href="service.html" class="nav-item nav-link">Hizmetler</a>
                                <a href="room.html" class="nav-item nav-link">Odalar</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Sayfalar</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="booking.php" class="dropdown-item active">Rezervasyon</a>
                                        <a href="team.html" class="dropdown-item">Ekibimiz</a>
                                        <a href="testimonial.html" class="dropdown-item">Yorumlar</a>
                                    </div>
                                </div>
                                <a href="contact.php" class="nav-item nav-link">İletişim</a>
                            </div>
                            <a href="login.php" class="btn btn-primary rounded-0 py-4 px-md-5 d-none d-lg-block">Giriş Yap<i class="fa fa-arrow-right ms-3"></i></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header End -->


        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Rezervasyon</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Anasayfa</a></li>
                            <li class="breadcrumb-item"><a href="#">Sayfalar</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Rezervasyon</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Booking Start -->
        <div class="container-fluid booking pb-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="bg-white shadow" style="padding: 35px;">
                    <div class="row g-2">
                        <div class="col-md-10">
                            <div class="row g-2">
                                <div class="col-md-3">
                                    <div class="date" id="date1" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input"
                                            placeholder="Giriş Tarihi" data-target="#date1" data-toggle="datetimepicker" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="date" id="date2" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" placeholder="Çıkış Tarihi" data-target="#date2" data-toggle="datetimepicker"/>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select">
                                        <option selected>Yetişkin</option>
                                        <option value="0">Yetişkin 0</option>
                                        <option value="1">Yetişkin 1</option>
                                        <option value="2">Yetişkin 2</option>
                                        <option value="3">Yetişkin 3</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select">
                                        <option selected>Çocuk</option>
                                        <option value="0">Çocuk 0</option>
                                        <option value="1">Çocuk 1</option>
                                        <option value="2">Çocuk 2</option>
                                        <option value="3">Çocuk 3</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <!--<button class="btn btn-primary w-100" >Rezerasyon Yapın</button>-->
                            <a class="btn btn-primary w-100" href="booking.php">Rezerasyon Yapın</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Booking End -->


        <!-- Booking Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Oda Rezervasyonu</h6>
                    <h1 class="mb-5"><span class="text-primary text-uppercase">Lüks Konalama</span> Rezervasyonunuzu Yapın</h1>
                </div>
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="row g-3">
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.1s" src="img/about-1.jpg" style="margin-top: 25%;">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="img/about-2.jpg">
                            </div>
                            <div class="col-6 text-end">
                                <img class="img-fluid rounded w-50 wow zoomIn" data-wow-delay="0.5s" src="img/about-3.jpg">
                            </div>
                            <div class="col-6 text-start">
                                <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.7s" src="img/about-4.jpg">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="wow fadeInUp" data-wow-delay="0.2s">
















        <form method="post" action="" role="form">
    <div class="row g-3">
        <div class="col-md-6">
            <div class="form-floating">
                <input type="text" name="isim" class="form-control" id="name" placeholder="Your Name" required="required">
                <label for="name">İsim Soyisim</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating">
                <input type="email" name="email" class="form-control" id="email" placeholder="Your Email" required="required">
                <label for="email">Email</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating date" id="date3" data-target-input="nearest">
                <input name="giris" type="text" class="form-control datetimepicker-input" id="checkin" placeholder="Check In" required="required" data-target="#date3" data-toggle="datetimepicker" />
                <label for="checkin">Giriş Tarihi</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating date" id="date4" data-target-input="nearest">
                <input name="cikis" type="text" class="form-control datetimepicker-input" id="checkout" placeholder="Check Out" required="required" data-target="#date4" data-toggle="datetimepicker" />
                <label for="checkout">Çıkış Tarihi</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating">
                <select name="yetiskin" class="form-select" id="select1">
                    <option value="0">Yetişkin 0</option>
                    <option value="1">Yetişkin 1</option>
                    <option value="2">Yetişkin 2</option>
                    <option value="3">Yetişkin 3</option>
                </select>
                <label for="select1">Yetişkin Sayısı</label>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-floating">
                <select name="cocuk" class="form-select" id="select2">
                    <option value="0">Çocuk 0</option>
                    <option value="1">Çocuk 1</option>
                    <option value="2">Çocuk 2</option>
                    <option value="3">Çocuk 3</option>
                </select>
                <label for="select2">Çocuk Sayısı</label>
            </div>
        </div>
        <div class="col-12">
            <div class="form-floating">
                <select name="oda" class="form-select" id="select3">
                    <option value="Standart Suit">Standart Suit</option>
                    <option value="Standart Plus Suit">Standart Plus Suit</option>
                    <option value="Aile Odası">Aile Odası</option>
                    <option value="Royal Oda">Royal Oda</option>
                    <option value="King Suit">King Suit</option>
                    <option value="Select Oda">Select Oda</option>
                </select>
                <label for="select3">Oda Seçiniz</label>
            </div>
        </div>
        <div class="col-12">
            <div class="form-floating">
                <textarea name="istek" class="form-control" placeholder="Special Request" id="message" style="height: 100px"></textarea>
                <label for="message">Özel İstek</label>
            </div>
        </div>
        <div class="col-12">
            <button class="btn btn-primary py-3 px-5" onclick="showAlert()" type="submit" name="gonder">Şimdi Rezervasyon Yapın</button>
        </div>
 </div>
</form>

















                        </div>
                    </div>
                </div>
            </div>
        </div>




        <br><br><br><br> <br><br><br><br>
        <!-- Booking End -->


       
        

        <!-- Footer Start -->
        <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container pb-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-4">
                        <div class="bg-primary rounded p-4">
                            <a href="index.html"><h1 class="text-white text-uppercase mb-3">Paradise</h1></a>
                            
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">İletişim</h6>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Kundu Mahallesi, Yaşar Sobutay
Bulvarı No:440/1 Aksu/Antalya</p>
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                        <p class="mb-2"><i class="fa fa-envelope me-3"></i>info@paradisehotel.com</p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-youtube"></i></a>
                            <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="row gy-5 g-4">
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Şirket</h6>
                                <a class="btn btn-link" href="about.html">Hakkımızda</a>
                                <a class="btn btn-link" href="contact.php">Bize Ulaşn</a>
                                <a class="btn btn-link" href="gizlilikpolitika.html">Gizlilik Politikası</a>
                                <a class="btn btn-link" href="sartlarvekosullar.html">Şartlar & Koşullar</a>
                                <a class="btn btn-link" href="contact.php">Destek</a>
                            </div>
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Hizmetler</h6>
                                <a class="btn btn-link" href="restoran.html">Yemek & Restoran</a>
                                <a class="btn btn-link" href="spa.html">Spa & Fitness</a>
                                <a class="btn btn-link" href="sporoyun.html">Spor & Oyun</a>
                                <a class="btn btn-link" href="etkinlikparti.html">Etkinlik & Parti</a>
                                <a class="btn btn-link" href="sporsalonuVeyoga.html">Spor Salonu & Yoga</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="index.html">Paradise Otel</a>, Bütün hakları saklıdır. 
                            
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a class="border-bottom" >Furkan</a>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="index.html">Anasayfa</a>
                                <a href="cerezler.html">Çerezler</a>
                                <a href="">Yardım</a>
                                <a href="SSS.html">SSS</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>




    
</body>


<?php
$link = mysqli_connect('localhost', 'root', '');
mysqli_select_db($link, 'paradise');

if (isset($_POST['gonder'])) {
    $isim = $_POST['isim'];
    $email = $_POST['email'];
    $giris = $_POST['giris'];
    $cikis = $_POST['cikis'];
    $yetiskin = $_POST['yetiskin'];
    $cocuk = $_POST['cocuk'];
    $oda = $_POST['oda'];
    $istek = $_POST['istek'];

    $insertQuery = "INSERT INTO rezervasyon (isim, email, giris, cikis, yetiskin, cocuk, oda, istek) 
                    VALUES ('$isim', '$email', '$giris', '$cikis', '$yetiskin', '$cocuk', '$oda', '$istek')";
    mysqli_query($link, $insertQuery);

    
    echo '<script type="text/javascript">';
    
    echo 'window.location.href = "kredikarti.php";'; // Yönlendirme için JavaScript kullanıyoruz
    echo '</script>';
}
?>

<script>
    function showAlert() {
      alert("Rezervasyonu tamamlamak için ödeme yapınız.");
    }
  </script>


</html>
